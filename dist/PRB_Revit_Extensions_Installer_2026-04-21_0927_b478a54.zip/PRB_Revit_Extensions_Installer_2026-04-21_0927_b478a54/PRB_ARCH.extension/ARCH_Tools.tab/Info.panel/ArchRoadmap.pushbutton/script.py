# -*- coding: utf-8 -*-
from pyrevit import forms
forms.alert(
    "ARCH modulis ruosiamas.\n\n"
    "Planuojamos funkcijos:\n"
    "- ARCH View/Sheet automatizacija\n"
    "- ARCH QA patikros\n"
    "- ARCH Parameter Transformer",
    title="PRB ARCH Roadmap"
)
