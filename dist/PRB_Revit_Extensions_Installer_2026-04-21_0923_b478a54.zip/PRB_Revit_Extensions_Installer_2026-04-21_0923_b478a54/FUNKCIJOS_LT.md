# PRB Revit Extensions - Funkciju aprasas

## 1) PRB_Core.extension (CORE.tab)
- Nustatymai.panel
  - Atnaujinti: atsisiuncia naujausia versija ir atnaujina Core/MEP/ARCH struktura.
  - Pagalba: rodo pagalbine informacija.
- Sheets.panel
  - AutoSheet: automatizuoja sheet kurima (v1).
  - BatchRename: masinis sheet pavadinimu keitimas.
- Views.panel
  - AutoSection: sekciju automatizavimo pagalbinis irankis.
- Dimensions.panel
  - AutoDim: matmenu automatizavimo pagalbinis irankis.
- Export.panel
  - SmartExport: centralizuotas eksporto paleidimas.

## 2) PRB_MEP.extension (MEP_Tools.tab)
- Tags.panel
  - AutoTag: automatizuotas taginimas (anti-overlap, taisykles, papildomos opcijos).
  - AlignTags: tagu lygiavimas.
  - TagRules: System->Tag taisykliu valdymas.
- NSIK.panel
  - AutoCoder: NSIK kodavimo taikymas pagal mapping.
  - LearnRules: taisykliu mokymosi funkcija.
  - ParameterTransformer: parametru export/import/rollback (v2).

## 3) PRB_ARCH.extension (ARCH_Tools.tab)
- Info.panel
  - ArchRoadmap: laikinas informacinis mygtukas apie planuojamas ARCH funkcijas.
