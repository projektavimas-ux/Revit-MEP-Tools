# PRB Revit Extensions - Diegimo instrukcija

## Paketo sudetis
- PRB_Core.extension
- PRB_MEP.extension
- PRB_ARCH.extension

## Diegimas
1. Isarchyvuokite ZIP i laikina aplanka.
2. Nukopijuokite visus tris `.extension` katalogus i pyRevit extensions vieta.
3. Perkraukite Revit/pyRevit.
4. Patikrinkite ar atsirado tab'ai: CORE, MEP_Tools ir ARCH_Tools.

## Atnaujinimai
- CORE.tab mygtukas „Atnaujinti“ pritaikytas split strukturai ir atnaujina visus tris extension katalogus.

## Pastaba
- Jei diegiama ant svarbios darbo aplinkos, rekomenduojama pasidaryti atsargine senos versijos kopija.
